module.exports = {
  name: 'example',
  slug: 'example',
  android: {
    package: 'com.example',
  },
  ios: {
    bundleIdentifier: 'com.example',
  },
  plugins: [['../../build']],
};
